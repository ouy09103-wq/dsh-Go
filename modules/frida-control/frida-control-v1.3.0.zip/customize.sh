#!/system/bin/sh
# Frida Control - customize.sh
# KernelSU 在解压模块后导入本脚本（独立模式，运行在 KSU busybox ash）。
#
# 职责：
#   1. 给脚本设可执行权限（KSU 解压后文件默认 0644）
#   2. 检查 frida-server 是否存在并可用
#
# 本脚本不写系统属性、不挂载任何路径、不加载 SELinux 规则、
# 不在 /data/local/tmp 新建文件。

ui_print "- Frida Control 正在安装..."

for f in service.sh action.sh ctl.sh uninstall.sh; do
  [ -f "$MODPATH/$f" ] && set_perm "$MODPATH/$f" 0 0 0755
done
[ -f "$MODPATH/config.prop" ] && set_perm "$MODPATH/config.prop" 0 0 0644
[ -f "$MODPATH/module.prop" ] && set_perm "$MODPATH/module.prop" 0 0 0644

OLD_FRIDA=/data/local/tmp/frida-server
HIDE_DIR=/data/adb/frida-hide
HIDE_NAME=ksud_helper
HIDE_TARGET="$HIDE_DIR/$HIDE_NAME"

# 读安装包内的 HIDE 开关
HIDE=$(sed -n 's/^HIDE=//p' "$MODPATH/config.prop" 2>/dev/null | head -n 1)
[ -z "$HIDE" ] && HIDE=1

if [ "$HIDE" = "1" ]; then
  mkdir -p "$HIDE_DIR" 2>/dev/null
  chmod 0700 "$HIDE_DIR" 2>/dev/null

  if [ -f "$HIDE_TARGET" ]; then
    chmod 0700 "$HIDE_TARGET" 2>/dev/null
    ui_print "- 隐藏目录已就绪: $HIDE_TARGET"
    # 旧位置若有残留副本，删掉，否则目录扫描仍能发现
    if [ -f "$OLD_FRIDA" ]; then
      rm -f "$OLD_FRIDA" 2>/dev/null
      ui_print "- 已清除旧位置的 frida-server"
    fi
  elif [ -f "$OLD_FRIDA" ]; then
    if cp -f "$OLD_FRIDA" "$HIDE_TARGET" 2>/dev/null; then
      chmod 0700 "$HIDE_TARGET" 2>/dev/null
      rm -f "$OLD_FRIDA" 2>/dev/null
      ui_print "- 已迁移并隐藏: $HIDE_TARGET"
      ui_print "- 原 $OLD_FRIDA 已删除"
    else
      ui_print "! 迁移失败，请检查存储空间"
    fi
  else
    ui_print "! 未找到 frida-server"
    ui_print "! 请放到 $HIDE_TARGET 并 chmod 700"
    ui_print "! （或放 $OLD_FRIDA，首次启动会自动迁移）"
  fi

  if pidof frida-server >/dev/null 2>&1 || pidof "$HIDE_NAME" >/dev/null 2>&1; then
    ui_print "- 注意：frida 进程当前正在运行，重启后生效"
  fi
else
  if [ -f "$OLD_FRIDA" ]; then
    [ -x "$OLD_FRIDA" ] || chmod 0755 "$OLD_FRIDA"
    ui_print "- 隐藏已关闭，使用 $OLD_FRIDA"
  else
    ui_print "! 隐藏已关闭，但未找到 $OLD_FRIDA"
  fi
fi

ui_print "- 安装完成"
ui_print "- 点模块「操作」或打开 WebUI 可启停 / 切换模式"
