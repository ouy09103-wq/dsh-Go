#!/system/bin/sh
# Frida Control - service.sh
# 开机 late_start 阶段执行。默认什么都不做（AUTOSTART=0），
# 避免 frida-server 开机常驻，暴露进程 / 端口 等特征。
# 需要开机自启时，把 config.prop 里的 AUTOSTART 改成 1。

MODDIR=${0%/*}
CONF="$MODDIR/config.prop"
STATE="$MODDIR/state"

AUTOSTART=0
[ -f "$CONF" ] && . "$CONF"

# 只有显式开启自启才启动
[ "$AUTOSTART" = "1" ] || exit 0

mkdir -p "$STATE" 2>/dev/null
echo "$(date '+%m-%d %H:%M:%S') AUTOSTART" >> "$STATE/frida.log"
sh "$MODDIR/ctl.sh" start >/dev/null 2>&1
exit 0
