#!/system/bin/sh
# Frida Control - action.sh
# KernelSU 管理器里点本模块「操作」按钮执行本脚本。
#
# 交互菜单：启动/停止、切换 usb/wifi 模式、查看状态
# 非交互参数（便于脚本调用）：
#   action.sh on | off | usb | wifi | status

# 补全 KSU/APatch 的工具路径（「操作」按钮与 WebUI 执行时都需要）
case "$PATH" in
  *"/data/adb/ksu/bin"*) ;;
  *) PATH="/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:$PATH"; export PATH ;;
esac

MODDIR=${0%/*}
# 若以纯文件名调用（如 `sh action.sh`），${0%/*} 等于文件名本身，需纠正
case "$MODDIR" in
  */*) ;;
  *) MODDIR=. ;;
esac
# 兜底：解析到脚本真正所在目录
if [ ! -f "$MODDIR/ctl.sh" ]; then
  d=$(dirname "$0" 2>/dev/null)
  [ -f "$d/ctl.sh" ] && MODDIR="$d"
fi
STATE="$MODDIR/state"
mkdir -p "$STATE" 2>/dev/null

ctl() { sh "$MODDIR/ctl.sh" "$@"; }
fpid() {
  p=$(pidof frida-server 2>/dev/null)
  [ -z "$p" ] && p=$(pidof -x frida-server 2>/dev/null)
  [ -z "$p" ] && p=$(ps -A 2>/dev/null | awk '/[f]rida-server/{print $2; exit}')
  echo "$p" | awk '{print $1}'
}

get_mode() {
  m=$(sed -n 's/^MODE=//p' "$MODDIR/config.prop" 2>/dev/null | head -n 1)
  [ -z "$m" ] && m=usb
  echo "$m"
}

# ---------- 非交互参数 ----------
case "$1" in
  on)     rm -f "$MODDIR/disable" 2>/dev/null; ctl start; exit $? ;;
  off)    ctl stop; exit $? ;;
  usb)    ctl set-mode usb; exit $? ;;
  wifi)   ctl set-mode wifi; exit $? ;;
  status) ctl status; exit $? ;;
esac

# ---------- 交互菜单 ----------
echo "======================================="
echo "            Frida Control"
echo "======================================="

p=$(fpid)
m=$(get_mode)
case "$m" in
  usb)  mtxt="usb  (ADB 转发)" ;;
  wifi) mtxt="wifi (局域网)" ;;
  *)    mtxt="local" ;;
esac

if [ -n "$p" ]; then
  echo "当前: 运行中 (pid=$p) | 模式: $mtxt"
else
  echo "当前: 未运行 | 模式: $mtxt"
fi

echo ""
echo "  1) 启动 frida"
echo "  2) 停止 frida"
echo "  3) 切换到 usb 模式  (ADB 转发，仅本机可达)"
echo "  4) 切换到 wifi 模式 (局域网，同网段可连)"
echo "  5) 查看详细状态"
echo "  0) 退出"
echo ""
printf "请选择 [0-5]: "
read choice

case "$choice" in
  1) rm -f "$MODDIR/disable" 2>/dev/null; echo ""; ctl start ;;
  2) echo ""; ctl stop ;;
  3) echo ""; ctl set-mode usb ;;
  4) echo ""; ctl set-mode wifi ;;
  5) echo ""; ctl status; exit 0 ;;
  0|"") echo "已取消"; exit 0 ;;
  *) echo "无效选择: $choice"; exit 1 ;;
esac

echo ""
echo "---------------------------------------"
ctl status
