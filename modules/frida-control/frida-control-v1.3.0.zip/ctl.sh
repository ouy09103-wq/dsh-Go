#!/system/bin/sh
# Frida Control - 控制逻辑
# 用法: ctl.sh start|stop|restart|status|mode|set-mode <usb|wifi|local>
#
# 三种连接模式，差异只在监听地址：
#   usb   -> 127.0.0.1   配合电脑端 `adb forward tcp:27042 tcp:27042`，仅本机可达
#   wifi  -> 0.0.0.0     无线调试 / 局域网直连，同网段设备可连
#   local -> 127.0.0.1   仅设备自身进程可达
#
# 设计要点（避免给检测器增加特征）：
#   - 不写任何系统属性（不用 resetprop）
#   - 不挂载任何路径（无 system 目录、无 system.prop、无 sepolicy.rule）
#   - 不在 /data/local/tmp 新增任何文件
#   - 状态与日志一律写在模块自己的目录内

# WebUI 经 ksud 的 su 执行时，busybox 工具不一定在默认 PATH 里，先补上
case "$PATH" in
  *"/data/adb/ksu/bin"*) ;;
  *) PATH="/data/adb/ksu/bin:/data/adb/ap/bin:/data/adb/magisk:$PATH"; export PATH ;;
esac

MODDIR=${0%/*}
case "$MODDIR" in
  *ctl.sh) MODDIR=$(dirname "$MODDIR") ;;
  */*) ;;
  # 以纯文件名调用（如 `sh ctl.sh`）时 ${0%/*} 就是文件名本身
  *) MODDIR=. ;;
esac

CONF="$MODDIR/config.prop"
STATE="$MODDIR/state"

# ---- 隐藏相关路径 ----
# /data/local/tmp 权限是 0731，普通 App 能列目录看到文件名，
# 所以 frida-server 不能放在那里。改放 /data/adb 下：
# /data/adb 是 0700 仅 root，非 root 进程在内核层就被拒绝访问。
HIDE_DIR=/data/adb/frida-hide
# 伪装后的文件名，不带 frida 字样
HIDE_NAME=ksud_helper
OLD_FRIDA=/data/local/tmp/frida-server

MODE=usb
PORT=27042
AUTOSTART=0
HIDE=1

[ -f "$CONF" ] && . "$CONF"
[ -z "$MODE" ] && MODE=usb
[ -z "$PORT" ] && PORT=27042
[ -z "$HIDE" ] && HIDE=1

FRIDA="$HIDE_DIR/$HIDE_NAME"
[ "$HIDE" = "0" ] && FRIDA="$OLD_FRIDA"

mkdir -p "$STATE" 2>/dev/null

log() { echo "$(date '+%m-%d %H:%M:%S') $*" >> "$STATE/frida.log"; }

# 取进程 pid（只取第一个，避免多 pid 拼接）
# 按伪装名或原名都能找到
fpid() {
  p=$(pidof "$HIDE_NAME" 2>/dev/null)
  [ -z "$p" ] && p=$(pidof frida-server 2>/dev/null)
  [ -z "$p" ] && p=$(pidof -x "$HIDE_NAME" 2>/dev/null)
  [ -z "$p" ] && p=$(ps -A 2>/dev/null | awk -v n="$HIDE_NAME" '$NF==n || /[f]rida-server/{print $2; exit}')
  echo "$p" | awk '{print $1}'
}

# 把 frida-server 迁移到隐藏目录（首次启动时自动做）
ensure_hidden() {
  [ "$HIDE" = "1" ] || return 0

  # 目标已就绪
  if [ -f "$FRIDA" ]; then
    chmod 0700 "$FRIDA" 2>/dev/null
    chmod 0700 "$HIDE_DIR" 2>/dev/null
    # 旧位置若还有副本，删掉，避免目录名泄漏
    [ -f "$OLD_FRIDA" ] && rm -f "$OLD_FRIDA" 2>/dev/null
    return 0
  fi

  # 从旧位置迁移过来
  if [ -f "$OLD_FRIDA" ]; then
    mkdir -p "$HIDE_DIR" 2>/dev/null
    chmod 0700 "$HIDE_DIR" 2>/dev/null
    if cp -f "$OLD_FRIDA" "$FRIDA" 2>/dev/null; then
      chmod 0700 "$FRIDA" 2>/dev/null
      rm -f "$OLD_FRIDA" 2>/dev/null
      log "MIGRATE $OLD_FRIDA -> $FRIDA"
      return 0
    fi
    return 1
  fi

  return 1
}

# ---- 根据模式解析监听地址 ----
listen_addr() {
  case "$MODE" in
    wifi)  echo "0.0.0.0" ;;
    local) echo "127.0.0.1" ;;
    *)     echo "127.0.0.1" ;;
  esac
}

# ---- 取本机局域网 IP ----
# /proc/net/fib_trie 中地址行在 "/32 host LOCAL" 的上一行
# 优先返回常见局域网网段（192.168 / 10. / 172.16-31），其次任意非回环地址
lan_ip() {
  ips=$(awk '
    /\/32 host LOCAL/ {
      gsub(/^[ \t|+\-]*/, "", prev)
      print prev
    }
    { prev = $0 }
  ' /proc/net/fib_trie 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | grep -v '^127\.')

  [ -z "$ips" ] && { echo ""; return; }

  # 优先 192.168.x.x
  pick=$(echo "$ips" | grep '^192\.168\.' | head -n 1)
  [ -n "$pick" ] && { echo "$pick"; return; }

  # 其次 10.x.x.x
  pick=$(echo "$ips" | grep '^10\.' | head -n 1)
  [ -n "$pick" ] && { echo "$pick"; return; }

  # 再次 172.16-31.x.x
  pick=$(echo "$ips" | grep -E '^172\.(1[6-9]|2[0-9]|3[01])\.' | head -n 1)
  [ -n "$pick" ] && { echo "$pick"; return; }

  echo "$ips" | head -n 1
}

# 列出所有可用地址（用于状态面板）
lan_ip_all() {
  awk '
    /\/32 host LOCAL/ {
      gsub(/^[ \t|+\-]*/, "", prev)
      print prev
    }
    { prev = $0 }
  ' /proc/net/fib_trie 2>/dev/null | grep -E '^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$' | grep -v '^127\.'
}

# ---- 端口监听状态 ----
# 返回: 0=未监听 / 1=仅回环 / 2=全部地址
# 按字段解析 /proc/net/tcp，$2=local_address(ADDR:PORT) $4=state
port_state() {
  [ "$PORT" -gt 0 ] || { echo 0; return; }
  h=$(printf '%04X' "$PORT")

  r=$(awk -v h="$h" '
    NR > 1 {
      split($2, a, ":")
      if (toupper(a[2]) == h && $4 == "0A") print a[1]
    }
  ' /proc/net/tcp /proc/net/tcp6 2>/dev/null)

  [ -z "$r" ] && { echo 0; return; }

  # 任一监听项是 0.0.0.0 / :: 即视为全部地址
  case "$r" in
    *00000000*) echo 2 ;;
    *:)         echo 2 ;;
    *)          echo 1 ;;
  esac
}

# ---- 已建立的连接数 ----
conn_count() {
  [ "$PORT" -gt 0 ] || { echo 0; return; }
  h=$(printf '%04X' "$PORT")

  n=$(awk -v h="$h" '
    NR > 1 {
      split($2, a, ":")
      if (toupper(a[2]) == h && $4 == "01") c++
    }
    END { print c + 0 }
  ' /proc/net/tcp /proc/net/tcp6 2>/dev/null)

  [ -z "$n" ] && n=0
  echo "$n"
}

do_start() {
  # 隐藏模式：先把二进制迁移到 0700 的 /data/adb 下
  ensure_hidden
  hrc=$?
  if [ "$HIDE" = "1" ] && [ $hrc -ne 0 ]; then
    echo "错误：无法准备隐藏目录 $HIDE_DIR"
    echo "（原文件 $OLD_FRIDA 也不存在，请先把 frida-server 放好）"
    return 1
  fi

  if [ ! -f "$FRIDA" ]; then
    echo "错误：找不到 $FRIDA"
    return 1
  fi
  [ -x "$FRIDA" ] || chmod 0700 "$FRIDA" 2>/dev/null

  p=$(fpid)
  if [ -n "$p" ]; then
    echo "frida 已在运行 (pid=$p)，先停止后按当前模式重启"
    do_stop > /dev/null 2>&1
  fi

  addr=$(listen_addr)

  # 进程名伪装：二进制本身已命名为 $HIDE_NAME（不含 frida 字样），
  # 进程在 ps / /proc/pid/comm 里显示为 $HIDE_NAME。
  # 这只改显示名，不影响 frida 的任何通信与注入行为。
  "$FRIDA" -D -l "$addr:$PORT" >> "$STATE/frida.log" 2>&1 &

  i=0
  while [ $i -lt 40 ]; do
    sleep 0.25
    p=$(fpid)
    [ -n "$p" ] && break
    i=$((i + 1))
  done

  if [ -n "$p" ]; then
    echo "$p" > "$STATE/pid"
    echo "running" > "$STATE/status"
    echo "已启动 (pid=$p)"
    echo "模式: $MODE   监听: $addr:$PORT"
    [ "$HIDE" = "1" ] && echo "隐藏: 已开启（进程名 $HIDE_NAME，位于 $HIDE_DIR）"
    log "START pid=$p mode=$MODE addr=$addr:$PORT hide=$HIDE"
    return 0
  else
    echo "failed" > "$STATE/status"
    echo "启动失败，日志: $STATE/frida.log"
    log "START FAIL mode=$MODE"
    return 1
  fi
}

do_stop() {
  p=$(fpid)
  if [ -z "$p" ]; then
    echo "frida 未在运行"
    echo "stopped" > "$STATE/status"
    rm -f "$STATE/pid" 2>/dev/null
    return 0
  fi

  kill -TERM $p 2>/dev/null
  i=0
  while [ $i -lt 20 ]; do
    sleep 0.25
    [ -z "$(fpid)" ] && break
    i=$((i + 1))
  done

  p2=$(fpid)
  if [ -n "$p2" ]; then
    kill -KILL $p2 2>/dev/null
    sleep 0.5
  fi

  if [ -z "$(fpid)" ]; then
    echo "stopped" > "$STATE/status"
    rm -f "$STATE/pid" 2>/dev/null
    echo "已停止 frida"
    log "STOP ok"
    return 0
  else
    echo "停止失败，残留 pid: $(fpid)"
    log "STOP FAIL"
    return 1
  fi
}

# 修改模式并写回 config.prop
set_mode() {
  m="$1"
  case "$m" in
    usb|wifi|local) ;;
    *) echo "无效模式: $m（可选 usb / wifi / local）"; return 1 ;;
  esac

  was_running=""
  [ -n "$(fpid)" ] && was_running=1

  if grep -q '^MODE=' "$CONF" 2>/dev/null; then
    sed -i "s/^MODE=.*/MODE=$m/" "$CONF" 2>/dev/null
  else
    echo "MODE=$m" >> "$CONF"
  fi
  MODE="$m"

  echo "模式已切换为: $m"
  log "SETMODE $m"

  if [ -n "$was_running" ]; then
    echo "检测到 frida 正在运行，按新模式重启 ..."
    do_stop > /dev/null 2>&1
    do_start
  fi
  return 0
}

do_status() {
  p=$(fpid)
  addr=$(listen_addr)
  ps=$(port_state)
  cc=$(conn_count)

  echo "============ Frida Control ============"

  if [ -f "$MODDIR/disable" ]; then
    echo "模块状态 : 已禁用"
  else
    echo "模块状态 : 已启用"
  fi

  case "$MODE" in
    usb)   echo "连接模式 : usb   (ADB 转发，仅本机可达)" ;;
    wifi)  echo "连接模式 : wifi  (局域网，同网段可连)" ;;
    local) echo "连接模式 : local (仅设备自身)" ;;
    *)     echo "连接模式 : $MODE" ;;
  esac

  echo "监听地址 : $addr:$PORT"

  if [ -n "$p" ]; then
    echo "frida进程: 运行中 (pid=$p)"
  else
    echo "frida进程: 未运行"
  fi

  # 隐藏状态与是否运行无关：未运行时文件位置同样会暴露
  if [ "$HIDE" = "1" ]; then
    echo "进程名   : $HIDE_NAME"
    if [ -f "$FRIDA" ]; then
      echo "隐藏     : 已开启（$HIDE_DIR，非 root 不可见）"
    else
      echo "隐藏     : 已开启，但二进制尚未就位"
    fi
    if [ -f "$OLD_FRIDA" ]; then
      echo "风险     : $OLD_FRIDA 仍存在，会被目录扫描发现"
    fi
  else
    echo "进程名   : frida-server"
    echo "隐藏     : 已关闭（二进制在 $OLD_FRIDA）"
  fi

  case "$ps" in
    2) echo "端口状态 : 监听中（全部地址）" ;;
    1) echo "端口状态 : 监听中（仅回环）" ;;
    *) echo "端口状态 : 未监听" ;;
  esac

  if [ "$cc" -gt 0 ]; then
    echo "当前连接 : $cc 条已建立"
  else
    echo "当前连接 : 无"
  fi

  echo "---------------------------------------"

  if [ -n "$p" ] && [ "$ps" != "0" ]; then
    case "$MODE" in
      usb)
        echo "怎么连   : 电脑端执行"
        echo "           adb forward tcp:$PORT tcp:$PORT"
        echo "           frida -H 127.0.0.1:$PORT -l xxx.js"
        ;;
      wifi)
        ip=$(lan_ip)
        if [ -n "$ip" ]; then
          echo "怎么连   : frida -H $ip:$PORT -l xxx.js"
          echo "设备 IP  : $ip"
        else
          echo "怎么连   : frida -H <设备IP>:$PORT -l xxx.js"
          echo "设备 IP  : 未获取到（可能未连 Wi-Fi）"
        fi
        ;;
      local)
        echo "怎么连   : 仅设备内进程可连 $addr:$PORT"
        ;;
    esac
  else
    echo "怎么连   : frida 未运行，点「操作」启动"
  fi

  if [ "$AUTOSTART" = "1" ]; then
    echo "开机自启 : 开"
  else
    echo "开机自启 : 关"
  fi
  echo "======================================="
}

case "$1" in
  start)    do_start ;;
  stop)     do_stop ;;
  restart)  do_stop >/dev/null 2>&1; do_start ;;
  status)   do_status ;;
  mode)     echo "当前模式: $MODE"; echo "可选: usb / wifi / local" ;;
  set-mode) set_mode "$2" ;;
  *)        echo "用法: ctl.sh {start|stop|restart|status|mode|set-mode <usb|wifi|local>}"; exit 1 ;;
esac
