#!/system/bin/sh
# Frida Control - uninstall.sh
# 卸载时停掉 frida 进程并清理模块状态。
# 保留二进制本体（$HIDE_DIR/ksud_helper 或 /data/local/tmp/frida-server），
# 方便卸载模块后继续手动使用。

MODDIR=${0%/*}

HIDE_NAME=ksud_helper

# 两种进程名都要找，否则改名后的进程会残留
pids=$(pidof "$HIDE_NAME" 2>/dev/null)
[ -z "$pids" ] && pids=$(pidof frida-server 2>/dev/null)

if [ -n "$pids" ]; then
  kill -TERM $pids 2>/dev/null
  sleep 0.5
  # 复查一次，必要时强制结束
  left=$(pidof "$HIDE_NAME" 2>/dev/null)
  [ -z "$left" ] && left=$(pidof frida-server 2>/dev/null)
  [ -n "$left" ] && kill -KILL $left 2>/dev/null
fi

rm -rf "$MODDIR/state" 2>/dev/null
